-- Day 3 update: added tenants table
CREATE DATABASE dashboard_project;

USE dashboard_project;

CREATE TABLE properties (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    location VARCHAR(100),
    rent DECIMAL(10,2)
);

CREATE TABLE tenants (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    contact VARCHAR(50),
    email VARCHAR(100)
);
