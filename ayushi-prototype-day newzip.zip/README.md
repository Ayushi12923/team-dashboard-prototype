# Property Dashboard Prototype (Day 7)

This is my prototype project for the Saraswati College assignment.  
I focused on **Prototype 1 (Property Dashboard)** and completed around 90% of the work.  

---

## Progress Summary
- **Entities completed**: Property, Tenant, Payment  
- **JSP pages created**: dashboard, properties, tenants, payment form, payment list  
- **SQL tables added**: properties, tenants, payments  
- **Application runs successfully on localhost**  
- **Pending work**: Hibernate + DB integration (not done yet)  

---

## Tech Stack
- Java (Spring Boot)  
- JSP, HTML, CSS  
- MySQL (tables created)  
- Maven  

---

## How to run
1. Open in IDE (I used IntelliJ).  
2. Run `Application.java`.  
3. Open browser: [http://localhost:8080/dashboard](http://localhost:8080/dashboard).  

👉 At this stage, JSP pages are placeholders with "work in progress" text.  
Database integration is not working yet.  

---

## Notes
- I learned how to create entities and basic JSP pages.  
- I was able to set up the database and tables in MySQL.  
- Still need to practice Hibernate/JPA to connect backend with DB.  
- I decided to focus only on Prototype 1 instead of making 2 prototypes, so I could push it further.  
