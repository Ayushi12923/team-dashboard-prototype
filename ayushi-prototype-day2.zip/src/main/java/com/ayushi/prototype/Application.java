package com.ayushi.prototype;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Entry point of the Spring Boot app
@SpringBootApplication
public class Application {
    public static void main(String[] args) {
        System.out.println("Running Ayushi's Property Dashboard (Day 2 progress)...");
        SpringApplication.run(Application.class, args);
    }
}
