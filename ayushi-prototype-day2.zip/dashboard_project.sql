-- Day 2 update: created properties table
CREATE DATABASE dashboard_project;

USE dashboard_project;

CREATE TABLE properties (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    location VARCHAR(100),
    rent DECIMAL(10,2)
);
