package com.ayushi.prototype;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Main Spring Boot app (Day 5 progress)
@SpringBootApplication
public class Application {
    public static void main(String[] args) {
        System.out.println("Running Ayushi's Property Dashboard (Day 5 progress)...");
        SpringApplication.run(Application.class, args);
    }
}
