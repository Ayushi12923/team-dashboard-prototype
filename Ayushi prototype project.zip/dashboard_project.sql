-- Day 1: Just creating database
CREATE DATABASE dashboard_project;
