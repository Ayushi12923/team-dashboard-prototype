package com.ayushi.prototype;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Starter class for Spring Boot
@SpringBootApplication
public class Application {
    public static void main(String[] args) {
        System.out.println("Starting Ayushi's Property Dashboard Prototype...");
        SpringApplication.run(Application.class, args);
    }
}
